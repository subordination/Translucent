Translucent
A community driven iOS WinterBoard theme. See your wallpaper through your App icons.

Web: http://translucent.subordination.co.uk/
Twitter: https://twitter.com/translucenticon
Support: https://github.com/subordination/Translucent

***

The 'Translucent Icon Template v0.0.1.psd' file is for use with ‘Translucent’ only.

***